from django.urls import path
from . import views

urlpatterns = [
    path("", views.login_view, name="login"),
    path("loading/", views.loading_view, name="loading"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("logout/", views.logout_view, name="logout"),
]