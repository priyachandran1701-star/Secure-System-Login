from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages


# LOGIN PAGE
def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('loading')   # go loading page
        else:
            messages.error(request, "Invalid username or password")
            return redirect('login')

    return render(request, 'login.html')


# LOADING PAGE
@login_required
def loading_view(request):
    return render(request, 'loading.html')


# DASHBOARD PAGE
@login_required
def dashboard(request):
    return render(request, 'dashboard.html')


# LOGOUT PAGE
def logout_view(request):
    logout(request)
    return redirect('login')